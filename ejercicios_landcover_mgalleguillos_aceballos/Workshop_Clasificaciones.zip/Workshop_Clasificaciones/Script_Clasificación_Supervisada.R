#==============================================================================================#
#=============== C�DIGO PARA REALIZACI�N DE CLASIFICACIONES SUPERVISADAS =============================####
#==============================================================================================#
  rm(list=ls())
  graphics.off()

#================= Carga de paquetes a utilizar ============================================####
  pkgs<-c("rgdal","sp","raster","rasterVis","rgeos", "RStoolbox","rasclass","reshape2","plotKML","spatialEco")
  lapply(pkgs,require, character.only=T)

#================= Carga de funci�n para extracci�n de firmas espectrales ============================================####  
  sacspec <- function(R,G,B,img,view) {
    if(dev.cur()[[1]]>1){dev.off()}
    # Visualizaci�n mapa de referencia para extracci�n de firma
    plotRGB(img,R,G,B,stretch='lin',axes=TRUE)    
    xy <- click(view, n=1,cell=T)
    npi = xy[[1]] ; nco = ncol(img[[1]]) ; nro = nrow(NDVI)
    y = trunc(npi/nco)+1
    x = nco-((y*nco)-npi)
    nrbands <- length(img@layers)
    bands <- seq(1,nrbands,1)
    par(mfrow=c(1,2))
    spectrum <- img[[1:nrbands]][y,x]
    plot(bands, spectrum, ylab="Reflectividad de superficie",xaxt='n',xlab='')
    axis(side = 1,at = 1:6,labels = c("BLUE","GREEN","RED","NIR","SWIR1","SWIR2"),las=2,xlab='')
    lines(bands, spectrum)
    pts_pos(x,y,img,R,G,B)
    par(mfrow=c(1,1))
  }

  pts_pos <- function(x,y,img,R,G,B) {
    plotRGB(img, r=R, g=G, b=B, stretch="lin")
    xp1 <- x*(abs(img@extent@xmin-img@extent@xmax) / (img@ncols))
    xp2 <- xp1 + img@extent@xmin
    yp1<- y*(abs(img@extent@ymin-img@extent@ymax) / (img@nrows))
    yp2 <- img@extent@ymax - yp1
    points(xp2, yp2, cex=2, pch=21, col="yellow")
  }
  
#=============== Definici�n de directorios de trabajo y salida =========================================================####
  # Directorio de trabajo (carpeta descargada del taller)
    wd <- "D:/Universidad/INVESTIGACION/CR2_2.0/Workshop_Clasificaciones/"
  # Directorio de salida
    out <- paste0(wd,"resultados/")
  # Sistemas de referencia espacial
    sr1 <- CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0")
    utm = CRS("+proj=utm +zone=19 +south +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0")
    
#=============== Carga de bandas satelitales para la fecha a clasificar =========================================================####
    b2016 <- stack(paste0(wd,"raster/2016/L8_ref-ndvi_2016.tif"))
  # Asignaci�n de nombres de las bandas
    names(b2016) <- c("b1_BLUE","b2_GREEN","b3_RED","b4_NIR","b5_SWIR1","b6_SWIR2","b7_NDVI")
  # Visualizaci�n bandas
    plot(b2016)
  # A�o a clasificar
    yr = "2016"
  # Separaci�n del �ndice de vegetaci�n NDVI
    NDVI <- b2016[[7]]
  # Carga �rea de estudio
    AE <- readOGR(paste0(wd,"vectores/Area_Estudio.shp"))
    AEgeo <- spTransform(x = AE,CRSobj = sr1)
    plot(AEgeo)
    
#=============== Carga de puntos de entrenamiento-validaci�n creados en Google Earth =========================================================####    

    c1 = readOGR(dsn = paste0(wd,"/vectores/",yr,"/[1] Urbano.kml"), layer="Urbano") ; c1@data[,1] <- 1
    c2 = readOGR(dsn = paste0(wd,"/vectores/",yr,"/[2] VegetacionManejada.kml"), layer="VegetacionManejada") ; c2@data[,1] <- 2
    c3 = readOGR(dsn = paste0(wd,"/vectores/",yr,"/[3] MatorralSueloDesnudo.kml"), layer="MatorralSueloDesnudo") ; c3@data[,1] <- 3
    c4 = readOGR(dsn = paste0(wd,"/vectores/",yr,"/[4] Bosque.kml"), layer="Bosque") ; c4@data[,1] <- 4
    c5 = readOGR(dsn = paste0(wd,"/vectores/",yr,"/[5] Agua.kml"), layer="Agua") ; c5@data[,1] <- 5
    
    GE <- list(c1,c2,c3,c4,c5)
 # Visualizaci�n �rea de estudio y puntos de entrenamiento-validaci�n
    plot(AEgeo)
    plot(c3,add=T)
   
#=============== Visualizaci�n de firmas espectrales =========================================================####    
  # Visualizaci�n autom�tica de firmas espectrales: 
    #DEBE HACER CLICK SOBRE EL MAPA PARA SELECCIONAR EL PIXEL AL QUE SE EXTRAER� LA FIRMA ESPECTRAL
    #EN LA CONSOLA SE MOSTRAR� EL VALOR DEL PIXEL PARA EL RASTER PUESTO EN "view = "
  sacspec(R = 4,G = 3,B = 2,img = b2016[[1:6]], view = NDVI)
  dev.off()
#=============== Generaci�n insumos previos Clasificaci�n supervisada con paquete rasclass =========================================================####    
   # Ruta resultados rasclass
     rut = paste0(out,"rasclass/",yr,"/")
    
   # Exportaci�n de cada banda a formato ASCII (NECESARIO PARA rasclass)
      for(bn in 1:nlayers(b2016)){
        ban <- b2016[[bn]]
        ## Exportaci�n de cada imagen apilada coregida topograficamente a formato ASCII
        raster::writeRaster(ban, filename=paste0(rut,"in/",names(ban),".asc"), format="ascii", overwrite=TRUE)
      cat(names(ban),sep="\n")
      }
   
  # Raster de referencia y lista vacia a rellenar
    r = raster(extent(NDVI),ncol= ncol((NDVI)) ,nrow= nrow((NDVI)),crs=utm ,vals=0) #Raster de referencia
    raz = list()
    
  # Ciclo para la Rasterizaci�n de vectores
    for(hh in 1:length(GE)){
      cc <- data.frame(spTransform(GE[[hh]],CRSobj = utm)) #Para s�lo usar 400 puntos por clase agrgar:[sample(1:nrow(GE[[hh]]), 400, replace=F),]
      cc <- data.frame(cc[3:4],cc[1]) 
      nu= as.numeric(as.character(cc[1,3]))
      raz[[hh]] <- rasterize(x=cc[,1:2] ,y=r ,field=nu ,background=0 ,na.rm=T)
    }
  
  # Obtenci�n de raster con todas las clases rasterizadas
    TEST = raz[[1]]+raz[[2]]+raz[[3]]+raz[[4]]+raz[[5]]
    sam = reclassify(TEST,c(-0.1,0.1,NA, 5.1,Inf,NA)) ; getValues(sam)
    plot(sam)
    zoom(sam) #Hacer CLICK sobre el mapa seleccionando las dos esquinas de un rect�ngulo
  # Exportaci�n de raster de puntos de entrenamiento-validaci�n  
    raster::writeRaster(sam, filename=paste0(rut,"in/","sample.asc"), format="ascii", overwrite=TRUE)
  
#=============== Clasificaci�n Supervisada de Im�genes rasclass ===================================================####    
  # Listado de archivos ASCII
    lista = list.files(path = paste0(rut,"in/"),pattern = ".asc",full.names = F)
    if(length(lista)==8){lista2 = lista[-8]}
  # Creaci�n del objeto rasclass leyendo la carpeta con archivos ASCII  
    object <- readRasterFolder(path = paste0(rut,"in/") ,samplename ="sample",filenames = lista2)
  # F�rmula de la clasificaci�n  
    object@formula
  # Datos utilizados de cada variable para cada pixel de entrenamiento
    spect <- object@data
  # Visualizaci�n de separabilidad de clases
    cc1 =  spect[spect$sample %in% 1,] #Urbano
    cc2 =  spect[spect$sample %in% 2,] #Vegetaci�n manejada
    cc3 =  spect[spect$sample %in% 3,] #Matorral y suelo desnudo  
    cc4 =  spect[spect$sample %in% 4,] #Bosque
    cc5 =  spect[spect$sample %in% 5,] #Agua
    
  # Separabilidad Banda a Banda
  #Medida de separabilidad de divergencia transformada: Valores entre 0 y 2
  #0 = Traslape completo entre las firmas de dos clases 
  #2 = Separaci�n completa entre las dos clases.
  #A mayor separabilidad, mejores resultados en la clasificaci�n
    clase1 <- cc2
    clase2 <- cc4
    separability(clase1[,8], clase2[,8], plot=TRUE)$TD #Segun NDVI
    
    #0.0 < x < 1.0 (separabilidad pobre)
    #1.0 < x < 1.9 (separabilidad moderada)
    #1.9 < x < 2.0 (separabilidad buena)
   
  # Separabilidad promedio entre clases (considerando todas las separabilidades entre bandas)
    sep=matrix(0,nrow = length(lista2),ncol = 1)
    for(u in 1:length(lista2)){
      y =u+1
      sep[u,] <- separability(clase1[,y], clase2[,y])$TD
    }    
  # Separabilidad media  
    median(sep)    
    
  # Clasificaci�n supervisada SVM ("splitfraction": Define el % de puntos utilizados en la validaci�n de la clasificaci�n)
    outlist <- list()
    outlist[['supportVector']] <- classifyRasclass(object, method = 'supportVector',splitfraction=0.3)
    summary(outlist[['supportVector']])
  
#=============== Exportaci�n de estad+isticas y mapa de Clasificaci�n Supervisada rasclass ===================================================####    
  # Exportaci�n de estad�sticas de acuracidad de la clasificaci�n
    summ <- capture.output(summary(outlist[['supportVector']]))
    cat(paste0(rut,"SVM Summary ",yr), summ, file=paste0(rut,"SupVect_Summary_",yr,"_1.csv"), sep="\n", append=TRUE)
  # Exportaci�n a formato ASCII de las clasificaciones efectuadas  
    rasclass::writeRaster(outlist[[1]]@predictedGrid,paste0(rut,"predict_supVec_",yr,"_1.asc"))
  # Importaci�n y visualizaci�n r�pida de la clasificaci�n efectuada 
    image(outlist[[1]]@predictedGrid)
    c2016 <- raster(paste0(rut,"predict_supVec_",yr,"_1.asc"))
    crs(c2016) <- utm
    plot(c2016)
  # Exportaci�n mapa con colores representativos de las clasificaciones efectuadas
    LC <- c("[01] Urbano", "[02] Vegetaci�n Manejada","[03] Matorral y suelo desnudo","[04] Bosque","[05] Agua")
    colores = c("gray50","darkmagenta","yellow","green4","blue")
    nclass = length(LC)
  # Definici�n de raster c�mo una variable categ�rica, y generaci�n de su "Raster Attribute Table" (RAT)
    cla = ratify(c2016,count=T) 
    rat <- levels(cla)[[1]] ; rat1 = rat
    rat$landcover <- LC
    rat <- rat[,c(1,3)]
    levels(cla)[[1]] <- rat
  # Dimensiones
    ancho <- ncol(c2016)
    alto <- nrow(c2016) 
  # Exportaci�n de mapa a colores de toda la extensi�n    
    png(filename = paste0(rut,"SupVect_COL_",yr,".png"),width = ancho+1000 ,height = alto+300)
      rasterVis::levelplot(cla, col.regions=colores,maxpixels =ancho*alto,
                           main="Clasificaci�n supervisada SVM 2016")
    dev.off() 
  # Exportaci�n de figuras a TIFF  
    raster::writeRaster(cla, filename=paste0(rut,yr,".tif",sep=''), format="GTiff", overwrite=TRUE)

#=============== Postclasificaci�n, Estad�sticas y gr�ficos a partir de las clasificaciones efectuadas ===================================================####    
  # Ordenaci�n datos para gr�fico de torta por clase
    dat <- c(rat1$COUNT[1],rat1$COUNT[2],rat1$COUNT[3],rat1$COUNT[4],rat1$COUNT[5])
    lab <- c(rat$landcover[1],rat$landcover[2],rat$landcover[3],rat$landcover[4],rat$landcover[5]) 
  # Transformaci�n a superficies
    val_m2 <- dat*900
    val_ha <- val_m2/10000
    val_km <- round(val_ha/100,1)
  # Transformaci�n a porcentaje  
    piepercent<- round(100*val_km/sum(val_km), 2)
  # Generaci�n gr�fico de torta  
    png(file=paste0(rut,"pie-chart landcover proportion",yr,".png",sep=''),height = 1000, width = 1300)
      pie(val_km, labels = paste0(piepercent,"%"," (",val_km,")",sep=''), main = paste("Proporci�n de cobertura de suelo ",yr," [km2]"),
          col = colores,border=F,cex.main=3,cex=2,init.angle=0)
          legend("topleft",LC, cex = 2,fill = colores)
    dev.off()
  
  # Obtenci�n de tabla resumen de superficies (ha,km2), por clase (mismos datos del gr�fico de torta)  
    RRR <- data.frame(LC,dat,val_m2,val_ha,val_km,piepercent); colnames(RRR) <-c("Landcover","nPix","Sup_m2","Sup_Ha","Sup_Km2","Sup_%") 
    write.csv(RRR,file=paste0(rut,"Summary_SuperficiexClase_",yr,".csv"))
